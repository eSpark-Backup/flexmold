﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxIpAddress = new System.Windows.Forms.TextBox();
            this.labelIP = new System.Windows.Forms.Label();
            this.buttonConnectClose = new System.Windows.Forms.Button();
            this.trackBarSize = new System.Windows.Forms.TrackBar();
            this.groupBoxConnection = new System.Windows.Forms.GroupBox();
            this.btnClientTime = new System.Windows.Forms.Button();
            this.btnTemp = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.btnCalibrXY = new System.Windows.Forms.Button();
            this.btnCalibrate = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnPrjOff = new System.Windows.Forms.Button();
            this.btnPrjOn = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBoxPosition = new System.Windows.Forms.GroupBox();
            this.numericUpDownPosY = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownPosX = new System.Windows.Forms.NumericUpDown();
            this.labelPosX = new System.Windows.Forms.Label();
            this.labelX = new System.Windows.Forms.Label();
            this.groupBoxSize = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnSetSizePosition = new System.Windows.Forms.Button();
            this.btnReadData = new System.Windows.Forms.Button();
            this.btnPrjText = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtSendData = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarSize)).BeginInit();
            this.groupBoxConnection.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBoxPosition.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPosY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPosX)).BeginInit();
            this.groupBoxSize.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBoxIpAddress
            // 
            this.textBoxIpAddress.Location = new System.Drawing.Point(148, 17);
            this.textBoxIpAddress.Name = "textBoxIpAddress";
            this.textBoxIpAddress.Size = new System.Drawing.Size(100, 20);
            this.textBoxIpAddress.TabIndex = 0;
            this.textBoxIpAddress.Text = "192.168.50.22";
            // 
            // labelIP
            // 
            this.labelIP.AutoSize = true;
            this.labelIP.Location = new System.Drawing.Point(6, 20);
            this.labelIP.Name = "labelIP";
            this.labelIP.Size = new System.Drawing.Size(61, 13);
            this.labelIP.TabIndex = 1;
            this.labelIP.Text = "IP-Address:";
            // 
            // buttonConnectClose
            // 
            this.buttonConnectClose.Location = new System.Drawing.Point(9, 43);
            this.buttonConnectClose.Name = "buttonConnectClose";
            this.buttonConnectClose.Size = new System.Drawing.Size(239, 23);
            this.buttonConnectClose.TabIndex = 3;
            this.buttonConnectClose.Text = "Connect";
            this.buttonConnectClose.UseVisualStyleBackColor = true;
            this.buttonConnectClose.Click += new System.EventHandler(this.buttonConnectClose_Click);
            // 
            // trackBarSize
            // 
            this.trackBarSize.Location = new System.Drawing.Point(6, 19);
            this.trackBarSize.Maximum = 20;
            this.trackBarSize.Minimum = 1;
            this.trackBarSize.Name = "trackBarSize";
            this.trackBarSize.Size = new System.Drawing.Size(226, 45);
            this.trackBarSize.TabIndex = 4;
            this.trackBarSize.Value = 5;
            // 
            // groupBoxConnection
            // 
            this.groupBoxConnection.Controls.Add(this.checkBox1);
            this.groupBoxConnection.Controls.Add(this.btnClientTime);
            this.groupBoxConnection.Controls.Add(this.btnTemp);
            this.groupBoxConnection.Controls.Add(this.textBox2);
            this.groupBoxConnection.Controls.Add(this.btnCalibrXY);
            this.groupBoxConnection.Controls.Add(this.btnCalibrate);
            this.groupBoxConnection.Controls.Add(this.button1);
            this.groupBoxConnection.Controls.Add(this.btnPrjOff);
            this.groupBoxConnection.Controls.Add(this.labelIP);
            this.groupBoxConnection.Controls.Add(this.btnPrjOn);
            this.groupBoxConnection.Controls.Add(this.textBoxIpAddress);
            this.groupBoxConnection.Controls.Add(this.buttonConnectClose);
            this.groupBoxConnection.Location = new System.Drawing.Point(16, 6);
            this.groupBoxConnection.Name = "groupBoxConnection";
            this.groupBoxConnection.Size = new System.Drawing.Size(254, 223);
            this.groupBoxConnection.TabIndex = 6;
            this.groupBoxConnection.TabStop = false;
            this.groupBoxConnection.Text = "Connection";
            // 
            // btnClientTime
            // 
            this.btnClientTime.Location = new System.Drawing.Point(163, 118);
            this.btnClientTime.Name = "btnClientTime";
            this.btnClientTime.Size = new System.Drawing.Size(73, 40);
            this.btnClientTime.TabIndex = 14;
            this.btnClientTime.Text = "Client Time";
            this.btnClientTime.UseVisualStyleBackColor = true;
            this.btnClientTime.Click += new System.EventHandler(this.btnClientTime_Click);
            // 
            // btnTemp
            // 
            this.btnTemp.Location = new System.Drawing.Point(163, 72);
            this.btnTemp.Name = "btnTemp";
            this.btnTemp.Size = new System.Drawing.Size(73, 40);
            this.btnTemp.TabIndex = 13;
            this.btnTemp.Text = "Get Temp.";
            this.btnTemp.UseVisualStyleBackColor = true;
            this.btnTemp.Click += new System.EventHandler(this.btnTemp_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(6, 166);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(137, 20);
            this.textBox2.TabIndex = 11;
            this.textBox2.Text = "ZD2 100,500;";
            // 
            // btnCalibrXY
            // 
            this.btnCalibrXY.Location = new System.Drawing.Point(149, 164);
            this.btnCalibrXY.Name = "btnCalibrXY";
            this.btnCalibrXY.Size = new System.Drawing.Size(91, 23);
            this.btnCalibrXY.TabIndex = 12;
            this.btnCalibrXY.Text = "CalibrateXY";
            this.btnCalibrXY.UseVisualStyleBackColor = true;
            this.btnCalibrXY.Click += new System.EventHandler(this.btnCalibrXY_Click);
            // 
            // btnCalibrate
            // 
            this.btnCalibrate.Location = new System.Drawing.Point(87, 118);
            this.btnCalibrate.Name = "btnCalibrate";
            this.btnCalibrate.Size = new System.Drawing.Size(73, 40);
            this.btnCalibrate.TabIndex = 10;
            this.btnCalibrate.Text = "Calibrate!";
            this.btnCalibrate.UseVisualStyleBackColor = true;
            this.btnCalibrate.Click += new System.EventHandler(this.btnCalibrate_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(8, 118);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(73, 40);
            this.button1.TabIndex = 9;
            this.button1.Text = "Send Plot File";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnPrjOff
            // 
            this.btnPrjOff.Location = new System.Drawing.Point(87, 72);
            this.btnPrjOff.Name = "btnPrjOff";
            this.btnPrjOff.Size = new System.Drawing.Size(73, 40);
            this.btnPrjOff.TabIndex = 8;
            this.btnPrjOff.Text = "Projection Off";
            this.btnPrjOff.UseVisualStyleBackColor = true;
            this.btnPrjOff.Click += new System.EventHandler(this.btnPrjOff_Click);
            // 
            // btnPrjOn
            // 
            this.btnPrjOn.Location = new System.Drawing.Point(8, 72);
            this.btnPrjOn.Name = "btnPrjOn";
            this.btnPrjOn.Size = new System.Drawing.Size(73, 40);
            this.btnPrjOn.TabIndex = 4;
            this.btnPrjOn.Text = "Projection On";
            this.btnPrjOn.UseVisualStyleBackColor = true;
            this.btnPrjOn.Click += new System.EventHandler(this.btnPrjOn_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnReadData);
            this.groupBox1.Controls.Add(this.btnSetSizePosition);
            this.groupBox1.Controls.Add(this.groupBoxPosition);
            this.groupBox1.Controls.Add(this.groupBoxSize);
            this.groupBox1.Location = new System.Drawing.Point(16, 231);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(254, 191);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Clock";
            // 
            // groupBoxPosition
            // 
            this.groupBoxPosition.Controls.Add(this.numericUpDownPosY);
            this.groupBoxPosition.Controls.Add(this.numericUpDownPosX);
            this.groupBoxPosition.Controls.Add(this.labelPosX);
            this.groupBoxPosition.Controls.Add(this.labelX);
            this.groupBoxPosition.Location = new System.Drawing.Point(8, 125);
            this.groupBoxPosition.Name = "groupBoxPosition";
            this.groupBoxPosition.Size = new System.Drawing.Size(237, 53);
            this.groupBoxPosition.TabIndex = 4;
            this.groupBoxPosition.TabStop = false;
            this.groupBoxPosition.Text = "Position";
            // 
            // numericUpDownPosY
            // 
            this.numericUpDownPosY.Increment = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.numericUpDownPosY.Location = new System.Drawing.Point(155, 19);
            this.numericUpDownPosY.Maximum = new decimal(new int[] {
            3000,
            0,
            0,
            0});
            this.numericUpDownPosY.Minimum = new decimal(new int[] {
            3000,
            0,
            0,
            -2147483648});
            this.numericUpDownPosY.Name = "numericUpDownPosY";
            this.numericUpDownPosY.Size = new System.Drawing.Size(77, 20);
            this.numericUpDownPosY.TabIndex = 4;
            this.numericUpDownPosY.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDownPosX
            // 
            this.numericUpDownPosX.Increment = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.numericUpDownPosX.Location = new System.Drawing.Point(47, 19);
            this.numericUpDownPosX.Maximum = new decimal(new int[] {
            3000,
            0,
            0,
            0});
            this.numericUpDownPosX.Minimum = new decimal(new int[] {
            3000,
            0,
            0,
            -2147483648});
            this.numericUpDownPosX.Name = "numericUpDownPosX";
            this.numericUpDownPosX.Size = new System.Drawing.Size(77, 20);
            this.numericUpDownPosX.TabIndex = 3;
            this.numericUpDownPosX.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // labelPosX
            // 
            this.labelPosX.AutoSize = true;
            this.labelPosX.Location = new System.Drawing.Point(132, 22);
            this.labelPosX.Name = "labelPosX";
            this.labelPosX.Size = new System.Drawing.Size(17, 13);
            this.labelPosX.TabIndex = 2;
            this.labelPosX.Text = "Y:";
            // 
            // labelX
            // 
            this.labelX.AutoSize = true;
            this.labelX.Location = new System.Drawing.Point(24, 22);
            this.labelX.Name = "labelX";
            this.labelX.Size = new System.Drawing.Size(17, 13);
            this.labelX.TabIndex = 0;
            this.labelX.Text = "X:";
            // 
            // groupBoxSize
            // 
            this.groupBoxSize.Controls.Add(this.trackBarSize);
            this.groupBoxSize.Location = new System.Drawing.Point(8, 49);
            this.groupBoxSize.Name = "groupBoxSize";
            this.groupBoxSize.Size = new System.Drawing.Size(238, 70);
            this.groupBoxSize.TabIndex = 3;
            this.groupBoxSize.TabStop = false;
            this.groupBoxSize.Text = "Size";
            // 
            // textBox1
            // 
            this.textBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox1.Location = new System.Drawing.Point(3, 16);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox1.Size = new System.Drawing.Size(490, 401);
            this.textBox1.TabIndex = 8;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textBox1);
            this.groupBox2.Location = new System.Drawing.Point(276, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(496, 420);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "ReceivedData";
            // 
            // btnSetSizePosition
            // 
            this.btnSetSizePosition.Location = new System.Drawing.Point(40, 13);
            this.btnSetSizePosition.Name = "btnSetSizePosition";
            this.btnSetSizePosition.Size = new System.Drawing.Size(82, 30);
            this.btnSetSizePosition.TabIndex = 5;
            this.btnSetSizePosition.Text = "Send CLock";
            this.btnSetSizePosition.UseVisualStyleBackColor = true;
            this.btnSetSizePosition.Click += new System.EventHandler(this.btnSetSizePosition_Click);
            // 
            // btnReadData
            // 
            this.btnReadData.Location = new System.Drawing.Point(129, 13);
            this.btnReadData.Name = "btnReadData";
            this.btnReadData.Size = new System.Drawing.Size(91, 30);
            this.btnReadData.TabIndex = 6;
            this.btnReadData.Text = "Read Data";
            this.btnReadData.UseVisualStyleBackColor = true;
            this.btnReadData.Click += new System.EventHandler(this.btnReadData_Click);
            // 
            // btnPrjText
            // 
            this.btnPrjText.Location = new System.Drawing.Point(12, 539);
            this.btnPrjText.Name = "btnPrjText";
            this.btnPrjText.Size = new System.Drawing.Size(760, 23);
            this.btnPrjText.TabIndex = 7;
            this.btnPrjText.Text = "Send Text";
            this.btnPrjText.UseVisualStyleBackColor = true;
            this.btnPrjText.Click += new System.EventHandler(this.btnPrjText_Click);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Checked = true;
            this.checkBox1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox1.Location = new System.Drawing.Point(14, 193);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(108, 17);
            this.checkBox1.TabIndex = 15;
            this.checkBox1.Text = "Append NewLine";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txtSendData);
            this.panel1.Location = new System.Drawing.Point(12, 427);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(760, 111);
            this.panel1.TabIndex = 10;
            // 
            // txtSendData
            // 
            this.txtSendData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtSendData.Location = new System.Drawing.Point(0, 0);
            this.txtSendData.Multiline = true;
            this.txtSendData.Name = "txtSendData";
            this.txtSendData.Size = new System.Drawing.Size(760, 111);
            this.txtSendData.TabIndex = 0;
            this.txtSendData.Text = "SP1; PU; PA 0,0; PD; PR 1000,0; PR 0,200; PR -1000,0; PR 0,-200; PU; PA 0,100; PD" +
    "; SI 80,60; LB NetPort23 Test OKAY?;DU";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(784, 561);
            this.Controls.Add(this.btnPrjText);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBoxConnection);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(800, 600);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(295, 362);
            this.Name = "Form1";
            this.Text = "LP-Clock";
            ((System.ComponentModel.ISupportInitialize)(this.trackBarSize)).EndInit();
            this.groupBoxConnection.ResumeLayout(false);
            this.groupBoxConnection.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBoxPosition.ResumeLayout(false);
            this.groupBoxPosition.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPosY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPosX)).EndInit();
            this.groupBoxSize.ResumeLayout(false);
            this.groupBoxSize.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxIpAddress;
        private System.Windows.Forms.Label labelIP;
        private System.Windows.Forms.Button buttonConnectClose;
        private System.Windows.Forms.TrackBar trackBarSize;
        private System.Windows.Forms.GroupBox groupBoxConnection;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBoxPosition;
        private System.Windows.Forms.NumericUpDown numericUpDownPosY;
        private System.Windows.Forms.NumericUpDown numericUpDownPosX;
        private System.Windows.Forms.Label labelPosX;
        private System.Windows.Forms.Label labelX;
        private System.Windows.Forms.GroupBox groupBoxSize;
        private System.Windows.Forms.Button btnPrjOn;
        private System.Windows.Forms.Button btnPrjOff;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnCalibrate;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button btnCalibrXY;
        private System.Windows.Forms.Button btnClientTime;
        private System.Windows.Forms.Button btnTemp;
        private System.Windows.Forms.Button btnSetSizePosition;
        private System.Windows.Forms.Button btnReadData;
        private System.Windows.Forms.Button btnPrjText;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtSendData;
    }
}

