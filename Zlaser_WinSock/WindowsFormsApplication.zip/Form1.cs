﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

// use net/socket functions
using System.Net;
using System.Net.Sockets;
using System.IO;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        // class variables
        Socket s = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        IPEndPoint iep;
        string old_content;
        string appNewline = Environment.NewLine;

        public Form1()
        {
            InitializeComponent();
        }


        private void timerDisplay_Tick(object sender, EventArgs e)
        {
            //if (checkBoxRun.Checked == false)
            //    return;

            //if (s.Connected == false)
            //    return;

            //this.textBox1.Text += senddata(getStream())+" ";
            //ReadMessage();
        }


        private void buttonConnectClose_Click(object sender, EventArgs e)
        {
            if (buttonConnectClose.Text == "Connect")
            {
                buttonConnectClose.Text = "Disconnect";
                connect();
            }
            else
            {
                buttonConnectClose.Text = "Connect";
                disconnect();
            }
        }


        private void connect()
        {
            IPAddress IP = IPAddress.Parse(textBoxIpAddress.Text);
            int Port = 23; // Telnetport is 23

            iep = new IPEndPoint(IP, Port);

            try
            {
                s.Connect(iep);                
                this.textBox1.Text += "Connected Successfully!";

            }
            catch (Exception ee)
            {
                MessageBox.Show("Could not connect!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                buttonConnectClose.Text = "Connect";
                s = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                this.textBox1.Text += "Error While Connection!"+ee.Message+Environment.NewLine;


            }
            
        }

        private void disconnect()
        {
            if (s.Connected == true)
            {
                s.Close();
                s = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            }
        }

        private string getTime()
        {
            return DateTime.Now.ToString("HH-mm-ss");
        }

        private int senddata(string send_content)
        {
            if (s.Connected)
            {
                if (send_content == old_content)
                    return 0;

                old_content = send_content;

                ASCIIEncoding enc = new ASCIIEncoding();
                byte[] content = enc.GetBytes(send_content);

                return s.Send(content); //s.Send(content, SocketFlags.None);
            }
            else { MessageBox.Show("Device is not connected!","Error Not Connected!",MessageBoxButtons.OK); return 0; }
        }



        //private void checkBoxRun_CheckedChanged(object sender, EventArgs e)
        //{
        //    if (checkBoxRun.Enabled == true)
        //    {
        //        timerDisplay.Enabled = true;
        //        this.textBox1.Text += "TimeOn: ";
        //    }
        //    else
        //    { timerDisplay.Enabled = false; this.textBox1.Text += "TimeOff: "; }
        //}



        private string getStream()
        {
            // get slider position
            int k = trackBarSize.Value;
            int sx = 10 * k;
            int sy = sx * 20 / 15;

            int posx = Convert.ToInt32(numericUpDownPosX.Value);
            int posy = Convert.ToInt32(numericUpDownPosY.Value);

            string time = getTime();
            string command_pre = 
                "SP1;" + appNewline + //select pen 1
                "ZH0;" + appNewline + //ZH (Projection- height)
                "PA " + posx.ToString() + "," + posy.ToString() + ";" + appNewline + //PA (Plot Absolute)
                                                                                     //Notation of the command:
                                                                                     //PA XVALUE, YVALUE;
                                                                                     //Plot Absolute draws a line from the last
                                                                                     //known coordinate to the coordinate given by
                                                                                     //PA x, y, (z)
                "PD;" + appNewline +  //PD (Pen Down)            Switches to a visible object
                "SI " + sx.ToString() + "," + sy.ToString() + ";";//SI (Absolute character size)    SI width, height LB Text    Sets the character size for all following   characters.

            string command_pos = "LB " + time + appNewline;//label   A text string is sent.

            return command_pre + command_pos;
        }

        private void btnPrjOn_Click(object sender, EventArgs e)
        {
            string setProjectionOn = "ZN;" + appNewline;
            //ZN(Projection on)
            //The projection can be switched on with “ZN”
            //again.A re-send of data is not necessary.
            //Notation of the command :
            //ZN;
            //Switches on projection which was switched   off with ZF.
            //Note:If the calibration has not finished successfully, the projection will not start automatically.A sending of ZN switches on the projection again but without calculating the drift compensation.

            try { this.textBox1.Text += "ON-"+senddata(setProjectionOn) + " "; } catch (Exception ee) { this.textBox1.Text += "ON_Error "+ee.Message; MessageBox.Show("Error while switching ON projector = " + ee.Message); }
        }

        private void btnPrjOff_Click(object sender, EventArgs e)
        {
            string setProjectionOff = "ZF; " + appNewline;//IN; LB Projection ON/Initialized DT;
            //ZF(Projection off)
            //Notation of the command :
            //ZF;
            //            Switches off projection.
            //The projection can be switched on with “ZN”
            //again.A re-send of data is not necessary.
            //ZN(Projection on)
            //Notation of the command :
            //ZN;
            //Switches on projection which was switched   off with ZF.
            //Note:If the calibration has not finished successfully, the projection will not start automatically.A sending of ZN switches on the projection again but without calculating the drift compensation.

            try { this.textBox1.Text += "OFF-" + senddata(setProjectionOff) + " "; } catch(Exception ee) { this.textBox1.Text += "OFF_Error " + ee.Message; MessageBox.Show("Error while switching off projector = "+ee.Message); }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            var fileContent = string.Empty;
            var filePath = string.Empty;
            try
            {
                using (OpenFileDialog openFileDialog = new OpenFileDialog())
                {
                    //openFileDialog.InitialDirectory = "c:\\";
                    openFileDialog.Filter = "Laser files (*.las)|*.las|Plot files (*.plt)|*.plt";
                    openFileDialog.FilterIndex = 2;
                    openFileDialog.RestoreDirectory = true;

                    if (openFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        //Get the path of specified file
                        filePath = openFileDialog.FileName;

                        //Read the contents of the file into a stream
                        var fileStream = openFileDialog.OpenFile();

                        using (StreamReader reader = new StreamReader(fileStream))
                        {
                            fileContent = reader.ReadToEnd();
                        }
                    }
                }

                this.textBox1.Text += "SentFileRes= "+ senddata(fileContent)+" ";
                this.textBox1.Text += "SentData= " + fileContent;
            }
            catch (Exception ee) { MessageBox.Show("Error while Reading file ="+ee.Message); }
            //MessageBox.Show(fileContent, "File Content at path: " + filePath, MessageBoxButtons.OK);
        }

        private void btnCalibrate_Click(object sender, EventArgs e)
        {
            string setCalibrate = "ZD;" + appNewline;
                //Drift compensation eliminates thermal and
                //mechanical drift.
                //Note:
                //If the calibration has not finished
                //successfully, the projection will switch off.
                //A sending of ZN switches on the projection
                //again but without calculating the drift
                //compensation.

            try { this.textBox1.Text += "Calibr-" + senddata(setCalibrate) + " "; } catch (Exception ee) { this.textBox1.Text += "Calibr" + ee.Message; MessageBox.Show("Error while Calibrating projector = " + ee.Message); }


        }

        private void btnCalibrXY_Click(object sender, EventArgs e)
        {
            string setCalibrate = this.textBox2.Text + appNewline;
//            The ZD command has an extension to tweak the projectors accuracy.
//The drift compensation points are required for long term stability and
//accuracy of a laser projector.
//Notation of the instruction:
//ZDnvalue dXvalue dYvalue ;
//            n is the drift compensation point to be modified
//            dx and dy are the offset values
//ZD2 100,500;
//            Note: The tweaking is only temporary unless the values are stored
//            with the ZDW command.
//For an effective usage of this function, the DAPs should be at
//the field borders

            try { this.textBox1.Text += "CalibrXY-" + senddata(setCalibrate) + " "; } catch (Exception ee) { this.textBox1.Text += "CalibrXY" + ee.Message; MessageBox.Show("Error while CalibratingXY projector = " + ee.Message); }


        }

        private void btnTemp_Click(object sender, EventArgs e)
        {
            string setCalibrate = "*GETTEMP; " + appNewline;

            try { this.textBox1.Text += "GetTemp-" + senddata(setCalibrate) + " "; } catch (Exception ee) { this.textBox1.Text += "GetTemp" + ee.Message; MessageBox.Show("Error while GetTemp projector = " + ee.Message); }

        }

        private void btnClientTime_Click(object sender, EventArgs e)
        {
            string setCalibrate = "*GETTIME; " + appNewline;

            try { this.textBox1.Text += "GetTime-" + senddata(setCalibrate) + " "; } catch (Exception ee) { this.textBox1.Text += "GetTime" + ee.Message; MessageBox.Show("Error while GetTime projector = " + ee.Message); }

        }

        private void btnSetSizePosition_Click(object sender, EventArgs e)
        {
            //if (checkBoxRun.Checked == false)
            //    return;

            if (s.Connected == false)
                return;

            this.textBox1.Text += senddata(getStream()) + " ";            
        }

        private void btnPrjText_Click(object sender, EventArgs e)
        {
            ASCIIEncoding enc = new ASCIIEncoding();
            byte[] content = enc.GetBytes(this.txtSendData.Text);//SP1; PU; PA 0,0; PD; PR 1000,0; PR 0,200; PR -1000,0; PR 0,-200; PU; PA 0,100; PD; SI 80,60; LB Telnet Test OKAY?;DU
            //**********HPGL Command 
            //SP (Select Pen)
            //PU (Pen Up)
            //PA (Plot Absolute)
            //PD (Pen Down)
            //PR (Plot Relative)
            //SI (Absolute character size)
            //LB (Label)
            //DU ***end of text string
            if(s.Connected)
                s.Send(content);//s.Send(content,SocketFlags.None);

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkBox1.Checked)
                appNewline = Environment.NewLine;
            else
                appNewline = "";
        }

        private void btnReadData_Click(object sender, EventArgs e)
        {
            Byte[] responseData = new byte[256];
            Int32 numberOfBytesRead = 0;
            try { numberOfBytesRead = s.Receive(responseData); this.textBox1.Text += "rec-" + numberOfBytesRead + " "; string response1 = System.Text.Encoding.ASCII.GetString(responseData, 0, numberOfBytesRead).Trim(); this.textBox1.Text += response1; } catch (Exception ee) { this.textBox1.Text += "RECVError-" + ee.Message;}

        }
    }
}
